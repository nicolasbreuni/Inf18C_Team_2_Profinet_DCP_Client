Profinet DCP Backend

Führen sie das Powershell Install Skript aus

ODER:

Profinet-backend Ordner verschieben in C://

node-red asuführen / oder installieren 
hierzu folgen sie: https://nodered.org/docs/getting-started/local

node-red-backend-flow in Node-red importieren. 


Test:
Die Tests finden gesammelt aus dem frontend Ordner statt mit dem Befehl:
"npm run backend-test"
