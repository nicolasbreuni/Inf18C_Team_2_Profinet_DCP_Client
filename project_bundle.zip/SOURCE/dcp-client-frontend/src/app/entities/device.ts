export interface Device {
    name: string;
    ip: string;
}
