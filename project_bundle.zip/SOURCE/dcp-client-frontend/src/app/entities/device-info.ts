export interface DeviceInfo {
    name: string;
    ip: string;
    mac: string;
    subnetMask: string;
    vendorValue: string;
    deviceRole: string;
}
